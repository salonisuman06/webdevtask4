import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { Component1Component } from './component1/component1.component';
import { Component2Component } from './component2/component2.component';
import { Component3Component } from './component3/component3.component';

const routes: Routes = [
  
  {
    path:'com1', component: Component1Component
  },
  {
    path:'com2', component: Component2Component
  },
  {
    path:'com3', component: Component3Component
  },

  {
    path: '**', redirectTo : '/com1'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
